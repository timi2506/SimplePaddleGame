import SwiftUI

struct GameView: View {
    @State private var ballPosition = CGPoint(x: 400, y: 300)
    @State private var ballVelocity = CGPoint(x: 5, y: 5)
    @State private var paddlePosition = CGFloat(400)
    @State private var score = 0

    @Binding var isPlaying: Bool

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                // Top Paddle
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 100, height: 20)
                    .position(x: geometry.size.width / 2, y: 50)

                // Bottom Paddle
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 100, height: 20)
                    .position(x: paddlePosition, y: geometry.size.height - 50)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                let newPosition = value.location.x
                                if newPosition > 50 && newPosition < geometry.size.width - 50 {
                                    paddlePosition = newPosition
                                }
                            }
                    )

                // Ball
                Circle()
                    .frame(width: 20, height: 20)
                    .position(x: ballPosition.x, y: ballPosition.y)
                    .onAppear {
                        startBallMovement(geometry: geometry)
                    }

                // Score Display
                Text("Score: \(score)")
                    .font(.title)
                    .position(x: geometry.size.width / 2, y: geometry.size.height / 2)
            }
        }
    }

    private func startBallMovement(geometry: GeometryProxy) {
        Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { timer in
            ballPosition.x += ballVelocity.x
            ballPosition.y += ballVelocity.y

            // Bounce off walls
            if ballPosition.x <= 10 || ballPosition.x >= geometry.size.width - 10 {
                ballVelocity.x = -ballVelocity.x
            }

            // Bounce off top paddle and ensure it doesn't fly off screen
            if ballPosition.y <= 70 && ballPosition.x > geometry.size.width / 2 - 50 && ballPosition.x < geometry.size.width / 2 + 50 {
                ballVelocity.y = -ballVelocity.y
                score += 1
            } else if ballPosition.y < 70 {
                ballVelocity.y = -ballVelocity.y
            }

            // Bounce off bottom paddle
            if ballPosition.y >= geometry.size.height - 70 && ballPosition.x > paddlePosition - 50 && ballPosition.x < paddlePosition + 50 {
                ballVelocity.y = -ballVelocity.y
            }

            // Hit the ground
            if ballPosition.y > geometry.size.height - 10 {
                timer.invalidate()
                isPlaying = false
            }
        }
    }
}
