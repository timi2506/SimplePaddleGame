import SwiftUI

@main
struct PaddleGameApp: App {
    @State private var isPlaying = false
    @State private var score = 0

    var body: some Scene {
        WindowGroup {
            if isPlaying {
                GameView(isPlaying: $isPlaying)
            } else {
                LaunchScreenView(isPlaying: $isPlaying, score: $score)
            }
        }
    }
}
