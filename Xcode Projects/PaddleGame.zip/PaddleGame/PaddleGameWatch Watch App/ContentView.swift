import SwiftUI

struct ContentView: View {
    @State private var ballPosition = CGPoint(x: 90, y: 90)
    @State private var ballVelocity = CGPoint(x: 5, y: 5)
    @State private var paddlePosition = CGFloat(90)
    @State private var score = 0

    var body: some View {
        VStack {
            ZStack {
                // Paddle
                RoundedRectangle(cornerRadius: 5)
                    .frame(width: 60, height: 10)
                    .position(x: paddlePosition, y: 140)

                // Ball
                Circle()
                    .frame(width: 10, height: 10)
                    .position(x: ballPosition.x, y: ballPosition.y)
            }
            .gesture(
                DragGesture()
                    .onChanged { value in
                        let newPosition = min(max(value.location.x, 30), 170) // Ensure paddle stays within bounds
                        paddlePosition = newPosition
                    }
            )

            Text("Score: \(score)")
                .font(.headline)

            Spacer()
        }
        .padding()
        .onAppear {
            startBallMovement()
        }
    }

    private func startBallMovement() {
        _ = Timer.scheduledTimer(withTimeInterval: 0.02, repeats: true) { timer in
            ballPosition.x += ballVelocity.x
            ballPosition.y += ballVelocity.y

            // Bounce off walls
            if ballPosition.x <= 5 || ballPosition.x >= 175 {
                ballVelocity.x = -ballVelocity.x
            }

            // Bounce off top paddle
            if ballPosition.y <= 150 && ballPosition.x > paddlePosition - 30 && ballPosition.x < paddlePosition + 30 {
                ballVelocity.y = -ballVelocity.y
                score += 1
            } else if ballPosition.y < 10 {
                ballVelocity.y = -ballVelocity.y
            }

            // Hit the ground
            if ballPosition.y > 170 {
                timer.invalidate()
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
