//
//  PaddleGameWatchApp.swift
//  PaddleGameWatch Watch App
//
//  Created by Tim Schuchardt on 09.06.2024.
//

import SwiftUI

@main
struct PaddleGameWatch_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
