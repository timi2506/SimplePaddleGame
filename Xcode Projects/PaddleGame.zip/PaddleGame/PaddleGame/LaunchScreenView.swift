import SwiftUI

struct LaunchScreenView: View {
    @Binding var isPlaying: Bool
    @Binding var score: Int

    var body: some View {
        VStack {
            Spacer()
            Text("Hit the Paddle")
                .font(.largeTitle)
                .padding()
            Text("Score: \(score)")
                .font(.title)
                .padding()
            Spacer()
            Button(action: {
                score = 0
                isPlaying = true
            }) {
                Text("Play")
                    .font(.title)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
            }
            Spacer()
        }
    }
}
